<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'CMS') ?> - Nature</title>
    <?php if (!empty($meta_desc)): ?>
        <meta name="description" content="<?= esc($meta_desc) ?>">
    <?php endif; ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= $theme_url ?>/assets/css/style.css">
</head>

<body class="d-flex flex-column min-vh-100">

    <nav class="navbar navbar-expand-lg navbar-nature">
        <div class="container">
            <a class="navbar-brand fw-bold" href="<?= localized_url() ?>">
                <i class="bi bi-leaf-fill me-2"></i>Ainvar CMS - Nature
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNav">
                <?= render_menu() ?>
                <ul class="navbar-nav ms-3">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= $base_url ?>login"><i class="bi bi-gear"></i></a>
                    </li>
                    <?php if (!empty($languages) && count($languages) > 1): ?>
                        <li class="nav-item dropdown ms-lg-3">
                            <a class="nav-link dropdown-toggle fw-bold" href="#" data-bs-toggle="dropdown">
                                <i class="bi bi-globe"></i> <?= strtoupper($current_lang ?? 'ES') ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <?php foreach ($languages as $l): ?>
                                    <li>
                                        <?php
                                        $ts = $translation_slugs ?? [];
                                        if (isset($ts[$l['code']])) {
                                            $href = ($l['code'] === ($default_lang ?? 'es'))
                                                ? base_url($ts[$l['code']])
                                                : base_url($l['code'] . '/' . $ts[$l['code']]);
                                        } else {
                                            $href = lang_url($l['code']);
                                        }
                                        ?>
                                        <a class="dropdown-item <?= ($current_lang ?? 'es') === $l['code'] ? 'active' : '' ?>"
                                            href="<?= $href ?>">
                                            <span class="me-2"><?= $l['flag'] ?? '🏳️' ?></span> <?= esc($l['name']) ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <main class="flex-grow-1">
        <?= $this->renderSection('content') ?>
    </main>

    <footer class="footer-nature">
        <div class="container text-center">
            <p class="mb-0">&copy; <?= date('Y') ?> - CMS Ainvar. Tema Nature.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= $theme_url ?>/assets/js/main.js"></script>
</body>

</html>