<?php $this->extend('front/themes/nature/layout') ?>

<?php $this->section('content') ?>
<div class="error-404">
    <div class="container">
        <h1>404</h1>
        <h2 class="mb-4">Página no encontrada</h2>
        <p class="text-muted mb-4">La página que buscas no existe o ha sido movida.</p>
        <a href="<?= $base_url ?>" class="btn btn-nature btn-lg">
            <i class="bi bi-house me-2"></i>Volver al inicio
        </a>
    </div>
</div>
<?php $this->endSection() ?>