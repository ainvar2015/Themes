// Medianoche theme - JS mínimo
document.addEventListener('DOMContentLoaded', function() {
    // Activar enlaces del menú según URL actual
    const currentPath = window.location.pathname;
    document.querySelectorAll('.navbar-medianoche .nav-link').forEach(link => {
        if (link.getAttribute('href') === currentPath || link.getAttribute('href') === window.location.href) {
            link.classList.add('active');
        }
    });
});
