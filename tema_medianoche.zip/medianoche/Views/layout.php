<!DOCTYPE html>
<html lang="es" data-bs-theme="dark">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'CMS') ?> - Medianoche</title>
    <?php if (!empty($meta_desc)): ?>
        <meta name="description" content="<?= esc($meta_desc) ?>">
    <?php endif; ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= $theme_url ?>/assets/css/style.css">
    <?= view('front/partials/ga4') ?>
</head>

<body class="d-flex flex-column min-vh-100">

    <nav class="navbar navbar-expand-lg navbar-medianoche">
        <div class="container">
            <a class="navbar-brand fw-bold" href="<?= localized_url() ?>">
                <i class="bi bi-moon-stars me-2"></i>Ainvar CMS - Medianoche
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" style="border-color: rgba(255, 255, 255, 0.5); color: rgba(255, 255, 255);" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <form action="<?= localized_url('buscar') ?>" method="get" class="d-flex ms-lg-3 my-2 my-lg-0" role="search">
                <input type="search" name="q" class="form-control form-control-sm me-2" minlength="2"
                    placeholder="<?= current_lang() === 'en' ? 'Search…' : 'Buscar…' ?>"
                    value="<?= esc($_GET['q'] ?? '') ?>" aria-label="Buscar">
                <button class="btn btn-outline-light btn-sm" type="submit"><i class="bi bi-search"></i></button>
            </form>
            <div class="collapse navbar-collapse" id="mainNav">
                <?= render_menu() ?>
                <ul class="navbar-nav ms-3">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= $base_url ?>login"><i class="bi bi-gear"></i></a>
                    </li>
                    <?php if (!empty($languages) && count($languages) > 1): ?>
                        <li class="nav-item dropdown ms-lg-3">
                            <a class="nav-link dropdown-toggle fw-bold" href="#" data-bs-toggle="dropdown">
                                <i class="bi bi-globe"></i> <?= strtoupper($current_lang ?? 'ES') ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <?php foreach ($languages as $l): ?>
                                    <li>
                                        <?php
                                        $ts = $translation_slugs ?? [];
                                        if (isset($ts[$l['code']])) {
                                            $href = ($l['code'] === ($default_lang ?? 'es'))
                                                ? base_url($ts[$l['code']])
                                                : base_url($l['code'] . '/' . $ts[$l['code']]);
                                        } else {
                                            $href = lang_url($l['code']);
                                        }
                                        ?>
                                        <a class="dropdown-item <?= ($current_lang ?? 'es') === $l['code'] ? 'active' : '' ?>"
                                            href="<?= $href ?>">
                                            <span class="me-2"><?= $l['flag'] ?? '🏳️' ?></span> <?= esc($l['name']) ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <main class="flex-grow-1">
        <?= $this->renderSection('content') ?>
    </main>

    <footer class="footer-medianoche">
        <div class="container text-center">
            <p class="mb-0">&copy; <?= date('Y') ?> - CMS Ainvar. Tema Medianoche.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= $theme_url ?>/assets/js/main.js"></script>
    <?= view('front/partials/cookie_consent') ?>
</body>

</html>