<?php $this->extend('front/themes/' . ($themePath ?? 'default') . '/layout') ?>

<?php $this->section('content') ?>
<?php $isModule = ($page['type'] ?? '') === 'module'; ?>

<div class="container py-5">
    <!-- Título: siempre centrado, ancho de lectura -->
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="row <?= $isModule ? '' : 'justify-content-center' ?>">
                <div class="<?= $isModule ? 'col-12' : 'col-lg-8' ?>">
                    <h1 class="mb-4 display-5 fw-bold"><?= esc($page['title']) ?></h1>
                </div>
            </div>
        </div>
    </div>

    <?php if ($isModule): ?>
        <!-- Páginas-módulo: contenido a ancho completo -->
        <?= $page['content'] ?>
    <?php else: ?>
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <?php if ($page['type'] === 'template' && !empty($template_fields)): ?>
                    <!-- ...tu bloque de campos de plantilla tal cual... -->
                <?php else: ?>
                    <div class="content">
                        <?= $page['content'] ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $this->endSection() ?>