<?php $this->extend('front/themes/medianoche/layout') ?>

<?php $this->section('content') ?>
<div class="hero">
    <div class="container">
        <h1>Bienvenido a Medianoche</h1>
        <p class="lead">Un tema oscuro y elegante para tu CMS.</p>
        <a href="<?= base_url('catalogo') ?>" class="btn btn-light btn-lg mt-3">
            <i class="bi bi-shop me-2"></i>Ver catálogo
        </a>
    </div>
</div>

<div class="container py-5">
    <div class="row text-center">
        <div class="col-md-4 mb-4">
            <div class="card card-medianoche h-100 p-4">
                <i class="bi bi-speedometer2 " style="font-size:3rem;color: var(--primary);"></i>
                <h4 class="mt-3">Rápido</h4>
                <p class="">Optimizado para cargar en milisegundos.</p>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card card-medianoche h-100 p-4">
                <i class="bi bi-phone " style="font-size:3rem;color: var(--primary);"></i>
                <h4 class="mt-3">Responsive</h4>
                <p class="">Se ve perfecto en cualquier dispositivo.</p>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card card-medianoche h-100 p-4">
                <i class="bi bi-palette " style="font-size:3rem;color: var(--primary);"></i>
                <h4 class="mt-3">Personalizable</h4>
                <p class="">Cambia el tema cuando quieras desde el admin.</p>
            </div>
        </div>
    </div>
</div>
<?php $this->endSection() ?>
