<?php $this->extend('front/themes/medianoche/layout') ?>

<?php $this->section('content') ?>
<div class="error-404">
    <div class="container">
        <h1>404</h1>
        <h2 class="mb-4">Página no encontrada</h2>
        <p class="mb-4" style="color: var(--muted);">La página que buscas no existe o ha sido movida.</p>
        <a href="<?= $base_url ?>" class="btn btn-medianoche btn-lg">
            <i class="bi bi-house me-2"></i>Volver al inicio
        </a>
    </div>
</div>
<?php $this->endSection() ?>
