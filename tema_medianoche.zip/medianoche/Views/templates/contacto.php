<?php $this->extend('front/themes/' . ($themePath ?? 'default') . '/layout') ?>

<?php $this->section('content') ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <h1 class="mb-4"><?= esc($page['title']) ?></h1>

            <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div>
            <?php endif; ?>
            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div>
            <?php endif; ?>

            <form action="<?= base_url('form/submit') ?>" method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="page_id" value="<?= $page['id'] ?>">
                <input type="hidden" name="page_slug" value="<?= $page['slug'] ?>">

                <?php foreach ($template_fields as $field):
                    $fname  = $field['name'];
                    $ftype  = $field['type'] ?? 'text';
                    $flabel = $field['label'] ?? $fname;
                ?>
                    <div class="mb-3">
                        <label class="form-label"><?= esc($flabel) ?></label>

                        <?php if ($ftype === 'textarea'): ?>
                            <textarea name="template_fields[<?= $fname ?>]" class="form-control" rows="5" required></textarea>

                        <?php elseif ($ftype === 'email'): ?>
                            <input type="email" name="template_fields[<?= $fname ?>]" class="form-control" required>

                        <?php elseif ($ftype === 'select' && !empty($field['options'])): ?>
                            <select name="template_fields[<?= $fname ?>]" class="form-select" required>
                                <?php foreach ($field['options'] as $opt): ?>
                                    <option value="<?= esc($opt) ?>"><?= esc($opt) ?></option>
                                <?php endforeach; ?>
                            </select>

                        <?php else: ?>
                            <input type="text" name="template_fields[<?= $fname ?>]" class="form-control" required>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>

                <button type="submit" class="btn btn-primary">Enviar</button>
            </form>
        </div>
    </div>
</div>
<?php $this->endSection() ?>